In this folder are Rocq/Coq proofs of the paper constituting its formalisation. This formalisation was done in Rocq version 9.1.0.

In the sections folder the proofs are broken out by the sections in the the paper.  The other unclassified proofs in this folder are general and/or interesting proofs regardless of section.

Every Teorem, lemma and corollary had been fully proven, in a few cases an axiom may be stated in place of a proof that can be found elswhere among these files. In every case where an axiom is stated in palce of a proof, a comment above the axiom points out where that proof may be found.

Every .v file has been made stand-alone to the extent possible and there may be facts that are proven more than once throughout the different sections.

Please review Appendix H Formalisation Index of the paper for an index of the formalisation proofs.

